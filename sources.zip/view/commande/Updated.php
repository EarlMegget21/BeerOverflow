<?php
    echo '<p>La Commande a bien été modifiée !</p>';
    require File::build_path(array('view','commande','DetailCommande.php'));

