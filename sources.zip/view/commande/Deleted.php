<?php
    echo '<p>La Commande a bien été supprimée !</p>';
    require File::build_path(array('view','commande','ListCommande.php'));
