<?php
    echo '<p>La Commande a bien été créée !</p>';
    require File::build_path(array('view','commande','ListCommande.php'));

