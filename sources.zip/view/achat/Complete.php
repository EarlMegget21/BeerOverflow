<?php

echo "Votre commande à bien été validée !";


?>