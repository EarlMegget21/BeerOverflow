<?php
    echo '<p>La Biere a bien été modifiée !</p>';
    require File::build_path(array('view','biere','DetailBiere.php'));

