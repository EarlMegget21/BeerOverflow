
<h1>Une envie en particulier ?</h1>
<a href="http://webinfo.iutmontp.univ-montp2.fr/~sonettir/e-commerce/index.php?action=search&controller=biere">Recherche Bières</a>
<a href="http://webinfo.iutmontp.univ-montp2.fr/~sonettir/e-commerce/index.php?action=readAll&controller=biere">Liste Bières</a>
