<div id="accueil">
    <div id="acc1">
        <h1>BeerOverflow</h1>
        <p>Ne jamais reporter à demain ce que l'on peut boire aujourd'hui</p>
    </div>
    <div id="acc2">
        <a href="http://webinfo.iutmontp.univ-montp2.fr/~sonettir/e-commerce/index.php?action=readAll&controller=biere">Découvrez nos Bières</a>
    </div>
</div>
