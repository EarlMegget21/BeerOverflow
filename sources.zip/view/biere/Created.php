<?php
    echo '<p>La Biere a bien été créée !</p>';
    require File::build_path(array('view','biere','ListBiere.php'));

