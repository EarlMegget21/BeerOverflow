<?php
    echo '<p>La Categorie a bien été modifiée !</p>';
    require File::build_path(array('View','categorie','DetailCategorie.php'));

