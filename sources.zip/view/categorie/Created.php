<?php
    echo '<p>La Categorie a bien été créée !</p>';
    require File::build_path(array('view','categorie','ListCategorie.php'));

