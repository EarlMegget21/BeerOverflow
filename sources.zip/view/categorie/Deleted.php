<?php
    echo '<p>La Categorie a bien été supprimée !</p>';
    require File::build_path(array('view','categorie','ListCategorie.php'));
