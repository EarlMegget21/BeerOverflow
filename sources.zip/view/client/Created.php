<?php
    echo '<p>Votre compte a bien été créé, un email de confirmation a été envoyé sur votre boite mail.</p>';
    require File::build_path(array('view','biere','Accueil.php'));

