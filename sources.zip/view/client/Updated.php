<?php
    echo '<p>Votre profil a bien été mis à jour !</p>';
    require File::build_path(array('view','biere','Accueil.php'));

