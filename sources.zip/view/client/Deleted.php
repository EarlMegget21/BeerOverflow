<?php
    echo '<p>Votre compte a bien été supprimé !</p>';
    require File::build_path(array('view','client','ListClient.php'));
