<?php
    echo '<p>La Brasserie a bien été supprimée !</p>';
    require File::build_path(array('view','brasserie','ListBrasserie.php'));
