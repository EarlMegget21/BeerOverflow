<?php
    echo '<p>La Brasserie a bien été créée !</p>';
    require File::build_path(array('view','brasserie','ListBrasserie.php'));

