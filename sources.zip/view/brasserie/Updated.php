<?php
    echo '<p>La Brasserie a bien été modifiée !</p>';
    require File::build_path(array('view','brasserie','DetailBrasserie.php'));

